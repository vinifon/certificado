#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-36 - CONTAR ATE 10 COM WHILE            \n"
       "Uma crianca esta aprendendo contagem numerica no computador.\n"
       "O programa deve imprimir os numeros de 1 ate 10\n"
       "usando while.\n\n");                                                                                 
printf("\n********************************************************************************************************\n");
    int i = 1;

    while (i <= 10) {
        printf("%d\n", i);
        i++;
    }
}
