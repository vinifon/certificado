#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-54 - VALIDAR NUMERO ENTRE 1 E 5               \n"
       "Um jogo aceita apenas valores entre 1 e 5.\n"
       "O programa repete a solicita��o enquanto o valor for inv�lido.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

int nivel;
    
    do {
        printf("Digite o nivel de dificuldade (1 a 5): ");
        scanf("%d", &nivel);
        
        if (nivel < 1 || nivel > 5) {
            printf("Nivel invalido! Digite um numero entre 1 e 5.\n");
        }
    } while (nivel < 1 || nivel > 5);
    
    printf("Nivel selecionado: %d\n", nivel);
}
