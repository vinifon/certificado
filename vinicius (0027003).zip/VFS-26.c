#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-26 - CONTAR DE 1 A 10           \n"
       "Um professor quer que o computador mostre automaticamente\n"
       "os numeros usados em uma chamada de alunos.\n"
       "O programa deve imprimir os numeros de 1 ate 10\n"
       "utilizando um laco for.\n\n");                                                                                  
printf("\n********************************************************************************************************\n");

 int i;

    for (i = 1; i <= 10; i++) {
        printf("%d\n", i);
    }
}
