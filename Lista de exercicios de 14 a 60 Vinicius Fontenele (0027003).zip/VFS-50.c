#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-50 - NUMERO POSITIVO OBRIGATORIO               \n"
       "Um sistema bancario aceita apenas valores positivos.\n"
       "O programa solicita numeros ate que o usuario digite um valor maior que zero.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

float num;
    
    do {
        printf("Digite um numero positivo: ");
        scanf("%f", &num);
        
        if (num <= 0) {
            printf("Valor invalido! O numero deve ser positivo.\n");
        }
    } while (num <= 0);
    
    printf("Numero valido recebido: %.2f\n", num);
}
