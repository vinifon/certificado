#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-55 - MAIOR NUMERO ATE NEGATIVO               \n"
       "O programa le numeros positivos digitados pelo usuario.\n"
       "Ele para quando um numero negativo for digitado.\n"
       "Ao final, mostra o maior numero informado.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

float num, maior = 0;
    int primeiro = 1;
    
    printf("Digite notas positivas (negativo para parar):\n");
    
    while (1) {
        scanf("%f", &num);
        
        if (num < 0) break;
        
        if (primeiro || num > maior) {
            maior = num;
            primeiro = 0;
        }
    }
    
    if (!primeiro) {
        printf("O maior numero informado foi: %.2f\n", maior);
    } else {
        printf("Nenhum numero positivo foi informado.\n");
    }
}
