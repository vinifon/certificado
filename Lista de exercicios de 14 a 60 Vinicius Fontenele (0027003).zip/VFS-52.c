#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-52 - SOMA ATE MULTIPLO DE 10              \n"
       "O programa soma numeros digitados pelo usuario.\n"
       "Ele para quando for digitado um numero multiplo de 10.\n"
       "Ao final, exibe a soma total.\n\n");                                                                             
printf("\n********************************************************************************************************\n");


    int num, soma = 0;
    
    printf("Digite numeros (multiplo de 10 para parar):\n");
    
    do {
        scanf("%d", &num);
        if (num % 10 != 0) {
            soma += num;
        }
    } while (num % 10 != 0);
    
    printf("Soma total dos valores: %d\n", soma);
}
