#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-53 - CONFIRMAR SAIDA COM 'S'                \n"
       "Apos cada operacao, o sistema pergunta se o usuario deseja sair.\n"
       "O menu continua ate que o usu�rio digite 's'.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

char opcao;
    
    do {
        printf("\n=== MENU DE CADASTRO ===\n");
        printf("1 - Cadastrar usuario\n");
        printf("2 - Listar usuarios\n");
        printf("3 - Buscar usuario\n");
        printf("Digite 's' para sair.\n");
        
        printf("Escolha uma opcao ou 's' para sair: ");
        scanf(" %c", &opcao);
        
    } while (opcao != 's' && opcao != 'S');
    
    printf("Programa encerrado.\n");
}
