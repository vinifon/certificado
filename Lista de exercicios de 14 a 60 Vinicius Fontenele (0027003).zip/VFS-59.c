#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-59 - ASSISTENTE DE DIRECAO (GPS)              \n"
       "Um robo le letras para decidir a direcao:\n"
       "N: Seguir para o Norte.\n"
       "S: Seguir para o Sul.\n"
       "L: Virar a Leste (Direita).\n"
       "O: Virar a Oeste (Esquerda).\n"
       "Qualquer outra letra: Comando invalido! Pare o robo.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

char direcao;
    
    printf("Digite a letra da direcao (N, S, L, O): ");
    scanf(" %c", &direcao);
    
    switch (direcao) {
        case 'N':
        case 'n':
            printf("Seguir para o Norte.\n");
            break;
        case 'S':
        case 's':
            printf("Seguir para o Sul.\n");
            break;
        case 'L':
        case 'l':
            printf("Virar � Leste (Direita).\n");
            break;
        case 'O':
        case 'o':
            printf("Virar � Oeste (Esquerda).\n");
            break;
        default:
            printf("Comando inv�lido! Pare o rob�.\n");
    }
}
