#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Vinicius Fontenele Santos - RA 0027003                                                         *\n");	
printf(" Programa VFS-51 - CONTAGEM REGRESSIVA               \n"
       "Uma corrida escolar faz contagem regressiva antes da largada.\n"
       "O programa deve exibir numeros de 10 at� 1 usando do...while.\n\n");                                                                             
printf("\n********************************************************************************************************\n");

int i = 10;
    
    printf("Contagem regressiva para a largada:\n");
    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);
    
    printf("Largada!\n");
}
